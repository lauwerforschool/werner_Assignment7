/**
 *
 * @param {import('../../mongoSetup')} db the mongo database to use
 * @param {import('express').Request} req the request object
 * @param {import('express').Response} res The response object
 */
 module.exports = async (db, req, res) => {
    try {
      let course = await db.model('course').findOne({_id: req.body.id})
      
      if(course){
        await db.model('course').deleteOne({_id: req.body.id});
        return res.status(200).send('course deleted');
      } else {
      return res.status(200).send('no course found ');
    }} catch (err) {
      res.status(500).send('failed to delete course');
      console.debug('failed to delete course: ' + err);
    }
  }
  