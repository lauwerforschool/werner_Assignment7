/**
 *
 * @param {import('../../mongoSetup')} db the mongo database to use
 * @param {import('express').Request} req the request object
 * @param {import('express').Response} res The response object
 */
 module.exports = async (db, req, res) => {
    try {
      //let student = await (db.model('student'))(req.body);
      //await student.save();
      //let student = await db.model('student').findOne({_id: req.body.id});
      //student = db.model.student.findOne({_id: req.body.id});
      let course = await db.model('course').find({courseName: req.body.courseName})
      
      if(course){
        await db.model('course').updateOne({courseName: req.body.courseName},{
            courseInstructor: req.body.courseInstructor
        },{upsert: true});
        return res.status(200).send('course updated');
      } else {
      return res.status(200).send('no course found ');
    }} catch (err) {
      res.status(500).send('failed to update course');
      console.debug('failed to update course: ' + err);
    }
  }
  