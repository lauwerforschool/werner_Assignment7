/**
 *
 * @param {import('../../mongoSetup')} db the mongo database to use
 * @param {import('express').Request} req the request object
 * @param {import('express').Response} res The response object
 */
 module.exports = async (db, req, res) => {
    try {
      let student = await db.model('student').findOne({fname: req.body.queryFname})
      
      if(student){
        await db.model('student').updateOne({fname: req.body.queryFname},{
            fname: req.body.fname,
            lname: req.body.lname
        },{upsert: true});
        return res.status(200).send('student updated');
      } else {
      return res.status(200).send('no student found ');
    }} catch (err) {
      res.status(500).send('failed to update student');
      console.debug('failed to update student: ' + err);
    }
  }