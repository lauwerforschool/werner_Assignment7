/**
 *
 * @param {import('../../mongoSetup')} db the mongo database to use
 * @param {import('express').Request} req the request object
 * @param {import('express').Response} res The response object
 */
 module.exports = async (db, req, res) => {
    try {
      //let student = await (db.model('student'))(req.body);
      //await student.save();
      //let student = await db.model('student').findOne({_id: req.body.id});
      //student = db.model.student.findOne({_id: req.body.id});
      let student = await db.model('student').find({_id: req.body.id})
      
      if(student){
        await db.model('student').updateOne({_id: req.body.id},{
            fname: req.body.fname
        },{upsert: true});
        return res.status(200).send('student updated');
      } else {
      return res.status(200).send('no student found ');
    }} catch (err) {
      res.status(500).send('failed to update student');
      console.debug('failed to update student: ' + err);
    }
  }
  