/**
 *
 * @param {import('../../mongoSetup')} db the mongo database to use
 * @param {import('express').Request} req the request object
 * @param {import('express').Response} res The response object
 */
 module.exports = async (db, req, res) => {
    try {
      let student = await db.model('student').find({studentID: req.body.studentId})
      if(student){
        await db.model('student').deleteOne({studentID: req.body.studentId});
        return res.status(200).send('student deleted from classes');
      } else {
      return res.status(200).send('no student found ');
    }} catch (err) {
      res.status(500).send('failed to delete student from classes');
      console.debug('failed to delete student from classes: ' + err);
    }
  }
  